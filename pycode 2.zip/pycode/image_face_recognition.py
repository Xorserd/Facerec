#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jul  5 16:08:39 2022

@author: xorserd
"""



#import required librarires
import cv2
import face_recognition

original_image= cv2.imread ('images/me2.jpg')


russ_image=face_recognition.load_image_file('images/rd.png')
russ_face_encodings= face_recognition.face_encodings(russ_image)[0]

bit_image=face_recognition.load_image_file('images/bit.jpg')
bit_face_encodings= face_recognition.face_encodings(bit_image)[0]

known_face_encodings = [russ_face_encodings,bit_face_encodings]
known_face_names = ["Russell Damali","Bithiah Obbo"]

image_to_recognize= face_recognition.load_image_file('images/me2.jpg')

all_face_locations = face_recognition.face_locations(image_to_recognize,model='hog')

all_face_encodings = face_recognition.face_encodings(image_to_recognize, all_face_locations)


#loop through each face location and face encornings found in the unknown image

for current_face_location, current_face_encoding in zip(all_face_locations, all_face_encodings):
    #split tuple
    top_pos,right_pos,left_pos,bottom_pos = current_face_location  
    all_matches = face_recognition.compare_faces(known_face_encodings,current_face_encoding)
    name_of_person = 'Unknown face'
    
    if True in all_matches:
        first_march_index = all_matches.index(True)
        name_of_person = known_face_names[first_march_index]
    #draw rectabel
    cv2.rectangle(original_image, (left_pos,top_pos),(right_pos,bottom_pos),(225,0,0),2)
    
    #display the name as the text in the image
    font = cv2.FONT_HERSHEY_DUPLEX 
    cv2.putText((original_image), name_of_person, (left_pos,bottom_pos), font, 0.5, (0,0,0),1)
    #display the image
    cv2.imshow("Faces Identified", original_image)
